# Less Compiler
Compile your `Less` code to `css` automatically with error checking.

## Usage
Create a `.less` file and start coding, when you save your file automatically generate 
css file in same directory.

## Features
* Error checking
* Light-weight
* Automatic 

---

**Contributions are welcome!**

---

**Provide your feedbacks and Report bug on below link**
> https://github.com/bajrangCoder/acode-plugin-less_compiler

## Change Logs
**`v1.0.0`**
- Released